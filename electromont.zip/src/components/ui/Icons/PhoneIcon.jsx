const PhoneIcon = ({ className = '' }) => {
    return (
      <svg
        className={className}
        viewBox="0 0 14 23"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M3.5 2C2.67157 2 2 2.67157 2 3.5V18.6562C2 19.4847 2.67157 20.1562 3.5 20.1562H10.5C11.3284 20.1562 12 19.4847 12 18.6562V3.5C12 2.67157 11.3284 2 10.5 2H10.4166L10.1731 2.58445C10.0178 2.95707 9.65368 3.19978 9.25 3.19978H4.75C4.34632 3.19978 3.98223 2.95707 3.82695 2.58445L3.58338 2H3.5ZM0 3.5C0 1.567 1.567 0 3.5 0H10.5C12.433 0 14 1.567 14 3.5V18.6562C14 20.5892 12.433 22.1562 10.5 22.1562H3.5C1.567 22.1562 0 20.5892 0 18.6562V3.5Z"
          fill="currentColor"
        />
      </svg>
    );
  };
  
  export default PhoneIcon;